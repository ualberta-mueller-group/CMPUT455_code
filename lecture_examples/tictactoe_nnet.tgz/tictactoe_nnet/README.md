# Cmput 455 sample code
# Tic-tac-toe Neural Network
# Written by Henry Du

Run tic_tac_toe_train_nnet.py to train the neural network.

- **multilayer_perceptron.py** <br>
  MLP class. <br>

- **tic_tac_toe_train_nnet.py** <br>
  Script to train MLP. <br>
  Three optimization methods are implemented: batch gradient descent (GD), modified stochastic gradient descent (SGD), and mini-batch SGD. The two SGD-like methods can produce a perfect or close-to-perfect model, but batch GD cannot (within a reasonable amount of time). 

- **tic_tac_toe_NN.npz** <br>
  Stores the trained model of the neural network. <br>

- **nn_player.py** <br>
  A tic-tac-toe player using the trained MLP. <br>
  Given a state, the player performs one-step look-ahead and queries MLP for wins/draws/losses. <br>
  <pre>
  If there are winning moves,
      randomly select a winning move and play.
  If there are drawing moves,
      randomly select a drawing moves and play.
  If there are only losing moves,
      randomly select a move and play.
  </pre>

# Tic-tac-toe Database

- **tic_tac_toe_DB** <br>
  A complete tic-tac-toe database. <br>
  Each line consists of `<board value>` <br>
  board - a string of a flattened board, encoded as: 0 - empty, 1 - black, 2 - white <br>
  value - the winner at the current posistion, encoded as: 0 - draw, 1 - black, 2 - white <br>
  For example, `000000000 0` represents an empty board and players can draw.<br>

- **db_player.py** <br>
  A tic-tac-toe player using the perfect play database. <br>
  Given a state, the player performs one-step look-ahead and queries the database for wins/draws/losses. <br>
  Same move selection mechanism as nn_player. <br>

