# Cmput 455 sample code
# Database player
# Do 1-ply search and then query the database for win/loss/draw
# Needs the tic-tac-toe database at ./data/tic_tac_toe_DB
# Written by Henry Du

import sys
import numpy as np
from game_basics import EMPTY, BLACK, WHITE
from tic_tac_toe_integer_eval import TicTacToe
from tic_tac_toe_gtp_connection import GtpConnection, point_to_coord


class DBPlayer(object):
    def __init__(self):
        self.name = "DB Player"
        self.version = 0.1
        
        self.db = {}
        self.get_database()

    def name(self):
        return self.name

    def get_database(self):
        f = open("./data/tic_tac_toe_DB", "r")
        lines = f.readlines()
        f.close()
        for line in lines:
            state, value = line.strip().split(' ')
            value = int(value)
            self.db[state] = value

    def genmove(self, state, verbose=False):
        color = state.toPlay
        board = [str(i) for i in state.board]
        moves = state.legalMoves()
        wins = []
        draws = []
        for i in range(len(moves)):
            board[moves[i]] = str(color)
            str_board = ''.join(board)
            win = self.db.get(str_board)
            if win == color:
                wins.append(moves[i])
            if win == EMPTY:
                draws.append(moves[i])
            board[moves[i]] = str(EMPTY)
            if verbose:
                s = point_to_coord(moves[i]) + " " + str(win) + "\n"
                sys.stderr.write(s)
                sys.stderr.flush()
        if wins:
            return np.random.choice(wins)
        if draws:
            return np.random.choice(draws)
        return np.random.choice(moves)
    
    
def run_player():
    db_player = DBPlayer()
    tic_tac_toe_board = TicTacToe()
    con = GtpConnection(db_player, tic_tac_toe_board)
    con.start_connection()


def main():
    run_player()


if __name__ == "__main__":
    main()
