# Cmput 455 sample code
# Multilayer Perceptron (MLP)
# - a simple neural network (NN) -
# Written by Henry Du

import pickle
import numpy as np


class MLP:
    """
    Multilayer Perceptron (MLP) - a simple neural network (NN)
    """
    def __init__(self, dims):
        self.dims = dims    # dimensions of each layer
        self.L = None       # number of layers
        self.weights = {}
        self.cache = {}

        self.__structure(dims)

    def __structure(self, dims):
        self.L = len(dims)  # number of layers
        for i in range(self.L-1):
            self.weights[f'W{i}'] = np.random.randn(dims[i], dims[i+1]) * np.sqrt(2.0/dims[i])  # Kaiming He weights initialization
            self.weights[f'B{i}'] = np.zeros((1, dims[i+1]))

    def derivative(self, A):
        """
        the derivative of ReLU at A
        """
        return 1.0 * (A > 0)

    def ReLU(self, Z):
        """
        activation function - Rectified Linear Unit
        """
        return Z * (Z > 0)
    
    def Softmax(self, Z):
        """
        activation function - Softmax
        """
        return np.exp(Z) / np.sum(np.exp(Z), axis=1, keepdims=True)

    def forward(self, X):
        """
        forward pass
        """
        self.cache.clear()
        self.cache['A0'] = X

        for i in range(1, self.L-1):
            self.cache[f'Z{i}'] = np.dot(self.cache[f'A{i-1}'], self.weights[f'W{i-1}']) + self.weights[f'B{i-1}']
            self.cache[f'A{i}'] = self.ReLU(self.cache[f'Z{i}'])

        i = self.L - 1
        self.cache[f'Z{i}'] = np.dot(self.cache[f'A{i-1}'], self.weights[f'W{i-1}']) + self.weights[f'B{i-1}']
        self.cache[f'A{i}'] = self.Softmax(self.cache[f'Z{i}'])
        return self.cache[f'A{self.L-1}']

    def backward(self, Y):
        """
        backward pass - backpropagation
        assume cross-entropy loss
        """
        self.cache[f'dA{self.L-1}'] = self.cache[f'A{self.L-1}'] - Y
        for i in reversed(range(self.L-1)):
            self.cache[f'dW{i}'] = np.dot(self.cache[f'A{i}'].T, self.cache[f'dA{i+1}']) / self.cache[f'A{i}'].shape[0]
            self.cache[f'dB{i}'] = np.sum(self.cache[f'dA{i+1}'], axis=0, keepdims=True) / self.cache[f'A{i}'].shape[0]
            if i > 0:
                self.cache[f'dA{i}'] = np.dot(self.cache[f'dA{i+1}'], self.weights[f'W{i}'].T) * self.derivative(self.cache[f'A{i}'])

    def update(self, lr):
        """
        update the weights by a small step
        """
        for i in range(self.L-1):
            self.weights[f'W{i}'] = self.weights[f'W{i}'] - lr * self.cache[f'dW{i}']
            self.weights[f'B{i}'] = self.weights[f'B{i}'] - lr * self.cache[f'dB{i}']
    
    def predict(self, X):
        Y_hat = self.forward(X)
        return np.argmax(Y_hat, axis=1)[0]

    def evaluate_MLP(self, X, Y):
        """
        evaluate the MLP model in terms of accuracy
        """
        Y_hat = self.forward(X)
        percent = np.sum(np.argmax(Y_hat, axis=1) == np.argmax(Y, axis=1)) / Y.shape[0] * 100
        return percent

    def store(self, path):
        """
        store model to path e.g. ./data/model.npz
        """
        model = {}
        for i in range(self.L-1):
            model[f'W{i}'] = self.weights[f'W{i}']
            model[f'B{i}'] = self.weights[f'B{i}']
        np.savez(path, **model)

    def load(self, path):
        """
        load model from path e.g. ./data/model.npz
        """
        model = np.load(path)
        for i in range(self.L-1):
            self.weights[f'W{i}'] = model[f'W{i}']
            self.weights[f'B{i}'] = model[f'B{i}']
