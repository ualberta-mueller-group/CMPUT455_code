"""
gtp_connection.py
Module for playing games of Go using GoTextProtocol

Parts of this code were originally based on the gtp module 
in the Deep-Go project by Isaac Henrion and Amos Storkey 
at the University of Edinburgh.
"""
from tabnanny import verbose
import traceback
from sys import stdin, stdout, stderr
import numpy as np
import re


class GtpConnection:
    def __init__(self, tic_tac_toe_engine, board, debug_mode=False):
        """
        Manage a GTP connection for a Go-playing engine

        Parameters
        ----------
        go_engine:
            a program that can reply to a set of GTP commandsbelow
        board: 
            Represents the current board state.
        """
        self._debug_mode = debug_mode
        self.tic_tac_toe_engine = tic_tac_toe_engine
        self.board = board
        self.commands = {
            "protocol_version": self.protocol_version_cmd,
            "quit": self.quit_cmd,
            "name": self.name_cmd,
            "boardsize": self.boardsize_cmd,
            "showboard": self.showboard_cmd,
            "clear_board": self.clear_board_cmd,
            "komi": self.komi_cmd,
            "version": self.version_cmd,
            "known_command": self.known_command_cmd,
            "genmove": self.genmove_cmd,
            "list_commands": self.list_commands_cmd,
            "play": self.play_cmd,
        }

        # used for argument checking
        # values: (required number of arguments,
        #          error message on argnum failure)
        self.argmap = {
            "boardsize": (1, "Usage: boardsize INT"),
            "komi": (1, "Usage: komi FLOAT"),
            "known_command": (1, "Usage: known_command CMD_NAME"),
            "genmove": (1, "Usage: genmove {w,b}"),
            "play": (2, "Usage: play {b,w} MOVE"),
            "legal_moves": (1, "Usage: legal_moves {w,b}"),
        }

    def write(self, data):
        stdout.write(data)

    def flush(self):
        stdout.flush()

    def start_connection(self):
        """
        Start a GTP connection. 
        This function continuously monitors standard input for commands.
        """
        line = stdin.readline()
        while line:
            self.get_cmd(line)
            line = stdin.readline()

    def get_cmd(self, command):
        """
        Parse command string and execute it
        """
        if len(command.strip(" \r\t")) == 0:
            return
        if command[0] == "#":
            return
        # Strip leading numbers from regression tests
        if command[0].isdigit():
            command = re.sub("^\d+", "", command).lstrip()

        elements = command.split()
        if not elements:
            return
        command_name = elements[0]
        args = elements[1:]
        if self.has_arg_error(command_name, len(args)):
            return
        if command_name in self.commands:
            try:
                self.commands[command_name](args)
            except Exception as e:
                self.debug_msg("Error executing command {}\n".format(str(e)))
                self.debug_msg("Stack Trace:\n{}\n".format(traceback.format_exc()))
                raise e
        else:
            self.debug_msg("Unknown command: {}\n".format(command_name))
            self.error("Unknown command")
            stdout.flush()

    def has_arg_error(self, cmd, argnum):
        """
        Verify the number of arguments of cmd.
        argnum is the number of parsed arguments
        """
        if cmd in self.argmap and self.argmap[cmd][0] != argnum:
            self.error(self.argmap[cmd][1])
            return True
        return False

    def debug_msg(self, msg):
        """ Write msg to the debug stream """
        if self._debug_mode:
            stderr.write(msg)
            stderr.flush()

    def error(self, error_msg):
        """ Send error msg to stdout """
        stdout.write("? {}\n\n".format(error_msg))
        stdout.flush()

    def respond(self, response=""):
        """ Send response to stdout """
        stdout.write("= {}\n\n".format(response))
        stdout.flush()

    def board2d(self):
        board = self.board.board
        board = [str(i) for i in board]
        board = " ".join(board)
        board = board[0:6] + "\n" + board[6:]
        board = board[0:13] + "\n" + board[13:]
        return board

    def protocol_version_cmd(self, args):
        """ Return the GTP protocol version being used (always 2) """
        self.respond("2")

    def quit_cmd(self, args):
        """ Quit game and exit the GTP interface """
        self.respond()
        exit()

    def name_cmd(self, args):
        """ Return the name of the TicTacToe engine """
        self.respond(self.tic_tac_toe_engine.name)

    def version_cmd(self, args):
        """ Return the version of the TicTacToe engine """
        self.respond(self.tic_tac_toe_engine.version)

    def clear_board_cmd(self, args):
        """ clear the board """
        self.board.resetGame()
        self.respond()

    def boardsize_cmd(self, args):
        """
        Reset the game with new boardsize args[0]
        """
        self.respond()

    def showboard_cmd(self, args):
        self.respond("\n" + self.board2d())

    def komi_cmd(self, args):
        """
        Set the engine's komi to args[0]
        """
        self.respond()

    def known_command_cmd(self, args):
        """
        Check if command args[0] is known to the GTP interface
        """
        if args[0] in self.commands:
            self.respond("true")
        else:
            self.respond("false")

    def list_commands_cmd(self, args):
        """ list all supported GTP commands """
        self.respond(" ".join(list(self.commands.keys())))

    def legal_moves_cmd(self, args):
        """
        List legal moves for color args[0] in {'b','w'}
        """
        self.respond()

    def play_cmd(self, args):
        """
        play a move args[1] for given color args[0] in {'b','w'}
        """
        if self.board.endOfGame():
            winner = self.board.winner()
            d = {0: "draw", 1: "black wins", 2: "white wins"}
            self.respond("game ended: " + d[winner])
            return
        board_color = args[0].lower()
        board_move = args[1]
        color = color_to_int(board_color)
        if color != self.board.toPlay:
            self.respond("Wrong color of the current player")
            return
        try:
            move = coord_to_point(args[1])
            self.board.play(move)
            self.respond()
            if self.board.endOfGame():
                winner = self.board.winner()
                d = {0: "draw", 1: "black wins", 2: "white wins"}
                self.respond("game ended: " + d[winner])
        except AssertionError:
            self.respond("Illegal Move: {}".format(board_move))
        return
        

    def genmove_cmd(self, args):
        """ generate a move for color args[0] in {'b','w'} """
        if self.board.endOfGame():
            winner = self.board.winner()
            d = {0: "draw", 1: "black wins", 2: "white wins"}
            self.respond("game ended: " + d[winner])
            return
        color = color_to_int(args[0].lower())
        if color != self.board.toPlay:
            self.respond("Wrong color of the current player")
            return
        move = self.tic_tac_toe_engine.genmove(self.board, verbose=True)
        move_coord = point_to_coord(move)
        try:
            self.board.play(move)
            self.respond(move_coord)
            if self.board.endOfGame():
                winner = self.board.winner()
                d = {0: "draw", 1: "black wins", 2: "white wins"}
                self.respond("game ended: " + d[winner])
        except AssertionError:
            self.respond("Illegal move: {}".format(move_coord))


def point_to_coord(point, boardsize=3):
    """
    Transform point given as board array index 
    to (row, col) coordinate representation.
    Special case: PASS is not transformed
    """
    column_letters = "ABCDEFGHJKLMNOPQRSTUVWXYZ"
    row, col = divmod(point, boardsize)
    row = 3 - row
    return column_letters[col] + str(row)


def coord_to_point(point_str, board_size=3):
    """
    Convert a string point_str representing a point, as specified by GTP,
    to a pair of coordinates (row, col) in range 1 .. board_size.
    Raises ValueError if point_str is invalid
    """
    s = point_str.lower()
    col_c = s[0]
    col = ord(col_c) - ord("a")
    assert 0 <= col < 3
    row = 3 - int(s[1:])
    assert 0 <= row < 3
    point = row * board_size + col
    return point


def color_to_int(c):
    """convert character to the appropriate integer code"""
    color_to_int = {"b": 1, "w": 2, "e": 0}
    return color_to_int[c]