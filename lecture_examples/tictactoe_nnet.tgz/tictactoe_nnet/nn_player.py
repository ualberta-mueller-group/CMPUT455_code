# Cmput 455 sample code
# Neural network player
# Do 1-ply search and then use neural network to predict win/loss/draw
# Need the trained model at ./data/tic_tac_toe_NN.npz
# Written by Henry Du

import sys
import numpy as np
from multilayer_perceptron import MLP
from game_basics import EMPTY, BLACK, WHITE
from tic_tac_toe_integer_eval import TicTacToe
from tic_tac_toe_gtp_connection import GtpConnection, point_to_coord


class NNPlayer(object):
    def __init__(self):
        self.name = "NN Player"
        self.version = 0.1
        
        self.dims = [9, 100, 50, 3]
        self.model = MLP(self.dims)

        self.model.load("./data/tic_tac_toe_NN.npz")

    def name(self):
        return self.name

    def genmove(self, state, verbose=False):
        color = state.toPlay
        board = np.array(state.board)
        moves = state.legalMoves()
        wins = []
        draws = []
        for i in range(len(moves)):
            board[moves[i]] = color
            X = board.reshape(1, -1)
            probs = self.model.forward(X)[0]
            Y_hat = np.argmax(probs)
            if Y_hat == color:
                wins.append(moves[i])
            if Y_hat == EMPTY:
                draws.append(moves[i])
            board[moves[i]] = EMPTY
            if verbose:
                s = point_to_coord(moves[i]) + " [{:.6f} {:.6f} {:.6f}]\n".format(probs[0], probs[1], probs[2])
                sys.stderr.write(s)
                sys.stderr.flush()
        if wins:
            return np.random.choice(wins)
        if draws:
            return np.random.choice(draws)
        return np.random.choice(moves)


def run_player():
    nn_player = NNPlayer()
    tic_tac_toe_board = TicTacToe()
    con = GtpConnection(nn_player, tic_tac_toe_board)
    con.start_connection()


def main():
    run_player()


if __name__ == "__main__":
    main()
