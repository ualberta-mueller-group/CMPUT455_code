# Cmput 455 sample code
# Run this script to train an MLP for tic-tac-toe
# Needs the tic-tac-toe database at ./data/tic_tac_toe_DB
# Stores the trained model at ./data/tic_tac_toe_NN.npz
# Written by Henry Du

import random
import numpy as np

from multilayer_perceptron import MLP


def get_dataset(db_path="./data/tic_tac_toe_DB"):
    """
    retrieve training examples from database
    """
    f = open(db_path, "r")
    lines = f.readlines()
    f.close()
    X, Y = [], []
    for line in lines:
        state, value = line.strip().split(' ')
        state = [int(char) for char in state]
        value = int(value)
        value_vector = [0, 0, 0]
        value_vector[value] = 1     # one-hot encoding
        X.append(state)
        Y.append(value_vector)
    X_train = np.array(X)
    Y_train = np.array(Y)
    return X_train, Y_train


def modified_SGD(model, X_train, Y_train, learning_rate, decay_rate, n_epochs, batch_size):
    """
    optimizer: A modified stochastic gradient descent with mini-batch.
    in each iteration
    picks n samples randomly to form a batch
    feeds the whole batch into MLP for traning
    Note: a sample in batch_i may also appear in batch_i+1
    this optimizer does not guarantee the model can observe the whole dataset in an epoch
    """
    training_accuracy = model.evaluate_MLP(X_train, Y_train)
    length = X_train.shape[0]
    n_iterations, remain = divmod(length, batch_size)
    for epoch in range(1, n_epochs+1):
        for _ in range(n_iterations):
            indices = np.random.choice(length, size=batch_size, replace=False)
            X = X_train[indices, :]
            Y = Y_train[indices, :]
            model.forward(X)
            model.backward(Y)
            model.update(learning_rate)
        if remain > 0:
            indices = np.random.choice(length, size=batch_size, replace=False)
            X = X_train[indices, :]
            Y = Y_train[indices, :]
            model.forward(X)
            model.backward(Y)
            model.update(learning_rate)
        
        if (epoch <= 500 and epoch % 100 == 0):
            learning_rate *= decay_rate
        training_accuracy = model.evaluate_MLP(X_train, Y_train)
        if training_accuracy == 100.0:
            print("SUCCESS: model fully trained with epoch = {}".format(epoch))
            return
        print("EPOCH {}: training set accuracy {:.2f}".format(epoch, training_accuracy))


def mini_batch_SGD(model, X_train, Y_train, learning_rate, decay_rate, n_epochs, batch_size):
    """
    optimizer: combine mini-batch and stochastic gradient descent
    """
    training_accuracy = model.evaluate_MLP(X_train, Y_train)
    length = X_train.shape[0]
    n_iterations, remain = divmod(length, batch_size)
    for epoch in range(1, n_epochs+1):
        XY = list(zip(X_train, Y_train))
        random.shuffle(XY)
        X_train, Y_train = zip(*XY)
        X_train = np.array(X_train)
        Y_train = np.array(Y_train)
        idx = 0
        for _ in range(1, n_iterations+1):
            model.forward(X_train[idx:idx+batch_size, :])
            model.backward(Y_train[idx:idx+batch_size, :])
            model.update(learning_rate)
            idx += batch_size
        if remain > 0:
            model.forward(X_train[idx:idx+remain, :])
            model.backward(Y_train[idx:idx+remain, :])
            model.update(learning_rate)
        
        if (epoch <= 300 and epoch % 100 == 0):
            learning_rate *= decay_rate
        training_accuracy = model.evaluate_MLP(X_train, Y_train)
        if training_accuracy == 100.0:
            print("SUCCESS: model fully trained with epoch = {}".format(epoch))
            return
        print("EPOCH {}: training set accuracy {:.2f}".format(epoch, training_accuracy))


def GD(model, X_train, Y_train, learning_rate, decay_rate, n_epochs, batch_size=None):
    """
    optimizer: batch gradient descent
    """
    training_accuracy = model.evaluate_MLP(X_train, Y_train)
    for epoch in range(1, n_epochs+1):
        model.forward(X_train)
        model.backward(Y_train)
        model.update(learning_rate)
        if (epoch <= 300 and epoch % 100 == 0):
            learning_rate *= decay_rate
        training_accuracy = model.evaluate_MLP(X_train, Y_train)
        if training_accuracy == 100.0:
            print("SUCCESS: model fully trained with epoch = {}".format(epoch))
            return
        print("EPOCH {}: training set accuracy {:.2f}".format(epoch, training_accuracy))


def main():
    # hyperparameters
    n_epochs = 3000
    learning_rate = 0.1
    decay_rate = 0.47
    batch_size = 10     # batch size for SGD or mini_batch_SGD
    dims = [9, 100, 50, 3]
    # optimizer = modified_SGD
    optimizer = mini_batch_SGD

    # initialize the moddel
    model = MLP(dims)

    # ground truth
    db_path = "./data/tic_tac_toe_DB"
    X_train, Y_train = get_dataset(db_path=db_path)

    # train
    optimizer(model, X_train, Y_train, learning_rate, decay_rate, n_epochs, batch_size)

    # store model
    model_path = "./data/tic_tac_toe_NN.npz"
    model.store(model_path)


if __name__ == "__main__":
    main()
